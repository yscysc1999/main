All actual info you can find here: https://bitcointalk.org/index.php?topic=5023676.0
Discord chat for differenmt questions: https://discord.gg/RkywAu5

Possible command line parameters can be checked if execute this: wildrig --help