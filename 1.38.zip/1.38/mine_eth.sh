#!/bin/bash

#################################
## Begin of user-editable part ##
#################################

POOL=eth1.xnpool.com:8008
WALLET=0x1A024aB708Cb1Fe10Cd5Ff6D2c1b1EF64EF85a5f.lolMinerWorker

#################################
##  End of user-editable part  ##
#################################

cd "$(dirname "$0")"

./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
while [ $? -eq 42 ]; do
    sleep 10s
    ./lolMiner --algo ETHASH --pool $POOL --user $WALLET $@
done
